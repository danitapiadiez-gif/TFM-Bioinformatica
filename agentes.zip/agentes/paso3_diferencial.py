import pandas as pd
import numpy as np
from scipy import stats
import os
from statsmodels.stats.multitest import multipletests

def ejecutar_diferencial(gse_id, df_norm, meta):
    """
    PASO 3: Análisis diferencial SÓLO si hay 2 grupos con al menos 2 muestras.
    Devuelve un DataFrame con genes significativos (FDR<0.05) o vacío.
    Además, guarda siempre 'resultados_completos.csv' (vacío si no hay diseño válido).
    """
    print(f"\n PASO 3: Análisis estadístico diferencial ({gse_id})...")
    path = os.path.join(os.path.expanduser("~"), "Desktop", f"TFM_{gse_id}")
    os.makedirs(path, exist_ok=True)
    
    # Asegurarnos de que existe la columna de grupo
    if 'grupo_analisis' not in meta.columns:
        print(" No existe columna 'grupo_analisis' en metadata. No hay diferencial.")
        resultados_vacios = pd.DataFrame()
        resultados_vacios.to_csv(os.path.join(path, "resultados_completos.csv"), index=False)
        return resultados_vacios
    
    grupos = meta['grupo_analisis'].value_counts()
    print(f"Distribución de grupos: {grupos.to_dict()}")
    
    # Necesitamos exactamente 2 grupos y mínimo 2 muestras por grupo
    if len(grupos) != 2 or grupos.min() < 2:
        print(" Diseño inválido para análisis diferencial (se requieren 2 grupos con ≥2 muestras cada uno).")
        resultados_vacios = pd.DataFrame()
        resultados_vacios.to_csv(os.path.join(path, "resultados_completos.csv"), index=False)
        return resultados_vacios
    
    g1, g2 = grupos.index.tolist()
    muestras_g1 = meta[meta['grupo_analisis'] == g1].index.intersection(df_norm.columns)
    muestras_g2 = meta[meta['grupo_analisis'] == g2].index.intersection(df_norm.columns)
    
    if len(muestras_g1) < 2 or len(muestras_g2) < 2:
        print(" Muestras insuficientes en algún grupo después de cruzar metadata con matriz.")
        resultados_vacios = pd.DataFrame()
        resultados_vacios.to_csv(os.path.join(path, "resultados_completos.csv"), index=False)
        return resultados_vacios
    
    print(f" Comparando '{g2}' (n={len(muestras_g2)}) vs '{g1}' (n={len(muestras_g1)})")
    
    # Medias por grupo
    mean_g1 = df_norm[muestras_g1].mean(axis=1)
    mean_g2 = df_norm[muestras_g2].mean(axis=1)
    log2fc = mean_g2 - mean_g1
    
    # t-test por gen (Welch), controlando NaN
    pvals = []
    for idx in df_norm.index:
        row = df_norm.loc[idx]
        stat, pval = stats.ttest_ind(
            row[muestras_g2],
            row[muestras_g1],
            equal_var=False,
            nan_policy='omit'
        )
        pvals.append(pval)
    
    pvals = np.array(pvals)
    
    # FDR (Benjamini-Hochberg)
    print(" Aplicando corrección FDR (Benjamini-Hochberg)...")
    _, pvals_adj, _, _ = multipletests(pvals, alpha=0.05, method='fdr_bh')
    
    resultados = pd.DataFrame({
        'GENE_SYMBOL': df_norm.index,
        'LogFC': log2fc.values,
        'pvalue': pvals,
        'adj_pvalue': pvals_adj
    })
    
    # Guardar resultados completos
    resultados.to_csv(os.path.join(path, "resultados_completos.csv"), index=False)
    
    # Filtrar significativos
    sig = resultados[resultados['adj_pvalue'] < 0.05]
    print(f"Genes significativos (FDR<0.05): {len(sig)}")
    
    return sig
import pandas as pd
import numpy as np
import os


def procesar_metadata(gse_id, gse, df_raw, ruta_analisis):
    """
    PASO 2 (versión árbol de decisión):
    - Normaliza matriz de expresión según tipo de análisis (ruta_analisis).
    - Procesa metadata y define 'grupo_analisis' cuando sea posible.
    
    Devuelve:
      df_norm  -> matriz normalizada
      meta     -> metadata con columna 'grupo_analisis'
    """
    print(f"\n PASO 2: Procesando metadata y normalizando ({gse_id}) [{ruta_analisis}]...")
    base_path = os.path.join(os.path.expanduser("~"), "Desktop", f"TFM_{gse_id}")
    os.makedirs(base_path, exist_ok=True)
    
    # 1. Copiar metadata y limpiar nombres de columnas
    meta = gse.phenotype_data.copy()
    meta.columns = [c.replace(".", "_").replace(" ", "_") for c in meta.columns]
    print(f" Columnas metadata: {list(meta.columns)}")
    
    # 2. NORMALIZACIÓN BASE (log2 + quantile)
    df = df_raw.copy()
    
    max_val = df.max().max()
    min_val = df.min().min()
    print(f" Rango de expresión bruto: min={min_val:.3f}, max={max_val:.3f}")
    
    # Log2 si parece que son intensidades grandes o counts
    if max_val > 50:
        print("Aplicando transformación log2(x+1)...")
        df = np.log2(df + 1)
    
    # Normalización tipo quantile (simplificada, neutra respecto a ruta)
    print("Normalización tipo quantile (simplificada)...")
    ranks = df.rank(method='average', axis=0)
    df_mean = df.stack().groupby(ranks.stack().astype(int)).mean()
    df_norm = ranks.stack().astype(int).map(df_mean).unstack()
    
    # Guardar matriz normalizada (antes de normalización específica de microarray/bulk)
    df_norm.to_csv(os.path.join(base_path, "matriz_normalizada.csv"))
    print(f" Matriz normalizada guardada: {df_norm.shape}")
    
    # 3. DEFINIR GRUPOS DE ANÁLISIS
    meta['grupo_analisis'] = asignar_grupos(gse_id, meta)
    print(f" Grupos detectados: {meta['grupo_analisis'].value_counts().to_dict()}")
    
    # Guardar metadata procesada
    meta.to_csv(os.path.join(base_path, "metadata_procesada.csv"))
    
    return df_norm, meta


def asignar_grupos(gse_id, meta):
    gse_id_upper = gse_id.upper()
    
    # REGLA ESPECÍFICA PARA GSE19188
    if gse_id_upper == "GSE19188":
        print(" Asignando Tumor/Normal para GSE19188 desde metadata")
        
        # 1) Intentar con 'characteristics_ch1_0_tissue_type'
        if "characteristics_ch1_0_tissue_type" in meta.columns:
            col = "characteristics_ch1_0_tissue_type"
            print(f"   Usando columna '{col}' para definir grupos.")
            valores = meta[col].astype(str).str.lower()
            grupos = valores.apply(
                lambda v: "Tumor" if ("tumor" in v or "cancer" in v or "nsclc" in v) else "Normal"
            )
            return grupos
        
        # 2) Si no existe, intentar con 'characteristics_ch1_3_status'
        if "characteristics_ch1_3_status" in meta.columns:
            col = "characteristics_ch1_3_status"
            print(f"   Usando columna '{col}' para definir grupos.")
            valores = meta[col].astype(str).str.lower()
            grupos = valores.apply(
                lambda v: "Tumor" if ("tumor" in v or "cancer" in v) else "Normal"
            )
            return grupos
        
        # 3) Si nada funciona, advertir y seguir con heurística general
        print(" No se encontraron columnas claras para Tumor/Normal en GSE19188. Se pasa a heurística general.")
    
    # A partir de aquí dejas el resto de la función como ya la tenías
    # (heurística general para el resto de GSEs)
    columnas = meta.columns
    candidatos = [c for c in columnas if any(
        key in c.lower() for key in [
            'group', 'condition', 'status', 'disease', 
            'phenotype', 'class', 'tumor', 'normal', 'response'
        ]
    )]
    
    if candidatos:
        col = candidatos[0]
        print(f" Columna candidata para grupos: {col}")
        grupos = meta[col].astype(str).replace({'nan': np.nan})
        
        if grupos.nunique() > 10:
            print(" Demasiadas categorías, usando modo 'Exploratorio'")
            return pd.Series('Exploratorio', index=meta.index)
        
        return grupos.fillna("Desconocido")
    
    fallback_cols = [c for c in columnas if any(
        k in c.lower() for k in ['title', 'source_name', 'description', 'characteristics']
    )]
    if fallback_cols:
        col = fallback_cols[0]
        print(f" Usando columna descriptiva para grupos: {col}")
        grupos = meta[col].astype(str)
        
        vc = grupos.value_counts()
        if len(vc) > 2:
            top2 = vc.index[:2].tolist()
            grupos = grupos.apply(lambda x: x if x in top2 else 'Otros')
        
        return grupos
    
    print(" No se han encontrado columnas claras para definir grupos. Modo exploratorio.")
    return pd.Series('Exploratorio', index=meta.index)